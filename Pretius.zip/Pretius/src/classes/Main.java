package classes;

import java.io.File;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		double suma = 0f;
		try {
			if (args.length > 0) {
				File file = new File(args[0]);
				Scanner scanner = new Scanner(file);
				while (scanner.hasNextLine()) {
					String line = scanner.nextLine().trim();
					System.out.println(line);
					String[] sections = line.split("@");
					for (int i = 0; i < sections.length; i++) {
						String[] pair = sections[i].split(":");
						if (pair[0].equals("amount")) {
							String prepareVal = (pair[1].substring(0, pair[1].length() - 3)).trim();
						}
					}
				}
				 System.out.println("Suma wszystkich operacji zawartych w pliku to: " + suma);
			} else {
				throw new Exception("Podaj nazwę pliku");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
